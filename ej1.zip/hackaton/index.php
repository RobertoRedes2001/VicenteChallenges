<?php 

$winner = 0;
$acumulador = 0;
$elfo = 1;
$elfWinner = 0;
$handle = fopen("c1.csv", "r");
while ($lineText = fgetcsv($handle)) {

    
    $acumulador += (int) $lineText[0];
    
    if ($lineText[0] === ",") {
        $elfo++;

        if ($acumulador > $winner) {
            $elfWinner = $elfo;
            $winner = $acumulador;
        }

        $acumulador = 0;
    }

    
}
print "Elfo numero ".$elfWinner."<br>";
print "Y sus calorias son ".$winner;